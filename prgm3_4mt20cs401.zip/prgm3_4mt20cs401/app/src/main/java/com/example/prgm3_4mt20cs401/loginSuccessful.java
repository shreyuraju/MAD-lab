package com.example.prgm3_4mt20cs401;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class loginSuccessful extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_successful);
    }
}