package com.example.a4mt20cs401_prgm06_parse_xml_json;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button xmlBtn,jsonBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        xmlBtn = findViewById(R.id.xmlBtn);
        jsonBtn = findViewById(R.id.jsonBtn);

        xmlBtn.setOnClickListener(this);
        jsonBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.equals(xmlBtn)) {
            Intent intent = new Intent(this,Data_xml_json.class);
            intent.putExtra("datatype","xml");
            startActivity(intent);
        }
        else if(v.equals(jsonBtn)){
            Intent intent = new Intent(this,Data_xml_json.class);
            intent.putExtra("datatype","json");
            startActivity(intent);
        }
    }
}