package com.example.a4mt20cs401_prgm06_parse_xml_json;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class Data_xml_json extends AppCompatActivity {

    TextView dataView,parsedDataView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_xml_json);

        dataView = findViewById(R.id.dataView);
        parsedDataView = findViewById(R.id.dataPassed);

        Intent intent =getIntent();
        String dataType = intent.getStringExtra("datatype");

        if(dataType.equals("xml")) {
            dataView.setText("XML DATA");
            try {
                InputStream is = getAssets().open("weather.xml");
                DocumentBuilderFactory dbFactory =DocumentBuilderFactory.newInstance();
                DocumentBuilder dbBuilder = dbFactory.newDocumentBuilder();
                Document doc = dbBuilder.parse(is);
                Element element = doc.getDocumentElement();
                element.normalize();
                NodeList nodeList = doc.getElementsByTagName("weather");

                for(int i=0 ; i<nodeList.getLength();i++) {
                    Node node = nodeList.item(i);
                    if(node.getNodeType()==Node.ELEMENT_NODE){
                        Element element1 = (Element) node;
                        parsedDataView.setText((parsedDataView.getText()+"City Name: "+getValue("city_name",element1)+"\n"));
                        parsedDataView.setText((parsedDataView.getText()+"Latitude: "+getValue("latitude",element1)+"\n"));
                        parsedDataView.setText((parsedDataView.getText()+"Longitude: "+getValue("longitude",element1)+"\n"));
                        parsedDataView.setText((parsedDataView.getText()+"Temperature: "+getValue("temperature",element1)+"\n"));
                        parsedDataView.setText((parsedDataView.getText()+"Humidity: "+getValue("humidity",element1)+"\n"));

                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }


        } else if(dataType.equals("json")) {
            dataView.setText("JSON DATA");
            parsedDataView.setText("Test JSON Parse Content\n");
        }
    }

    private String getValue(String tag, Element element1) {
        NodeList nodeList = element1.getElementsByTagName(tag).item(0).getChildNodes();
        Node node = nodeList.item(0);
        return node.getNodeValue();
    }
}