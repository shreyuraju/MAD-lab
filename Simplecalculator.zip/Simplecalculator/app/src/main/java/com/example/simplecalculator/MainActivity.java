package com.example.simplecalculator;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnOne,btnTwo,btnThree,btnFour,btnFive,btnSix,btnSeven,btnEight,btnNine,btnZero;
    Button btnAdd,btnMinus,btnMul,btnDiv,btnEqual,btnDot,btnClear;
    TextView textResult;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnOne = findViewById(R.id.btnOne);
        btnTwo = findViewById(R.id.btnTwo);
        btnThree = findViewById(R.id.btnThree);
        btnFour = findViewById(R.id.btnFour);
        btnFive = findViewById(R.id.btnFive);
        btnSix = findViewById(R.id.btnSix);
        btnSeven = findViewById(R.id.btnSeven);
        btnEight = findViewById(R.id.btnEight);
        btnNine = findViewById(R.id.btnNine);
        btnZero = findViewById(R.id.btnZero);
        btnAdd = findViewById(R.id.btnAdd);
        btnMinus = findViewById(R.id.btnMinus);
        btnMul = findViewById(R.id.btnMul);
        btnDiv = findViewById(R.id.btnDiv);
        btnEqual = findViewById(R.id.btnEqual);
        btnDot = findViewById(R.id.btnDot);
        btnClear = findViewById(R.id.btnClear);
        textResult = findViewById(R.id.textView);
        textResult.setText("");
        btnOne.setOnClickListener(this);
        btnTwo.setOnClickListener(this);
        btnThree.setOnClickListener(this);
        btnFour.setOnClickListener(this);
        btnFive.setOnClickListener(this);
        btnSix.setOnClickListener(this);
        btnSeven.setOnClickListener(this);
        btnEight.setOnClickListener(this);
        btnNine.setOnClickListener(this);
        btnZero.setOnClickListener(this);
        btnAdd.setOnClickListener(this);
        btnMinus.setOnClickListener(this);
        btnDiv.setOnClickListener(this);
        btnMul.setOnClickListener(this);
        btnEqual.setOnClickListener(this);
        btnDot.setOnClickListener(this);
        btnClear.setOnClickListener(this);
    }
    @Override
    public void onClick (@NonNull View v) {
        if(v.equals(btnOne))
            textResult.append("1");
        if(v.equals(btnTwo))
            textResult.append("2");
        if(v.equals(btnThree))
            textResult.append("3");
        if(v.equals(btnFour))
            textResult.append("4");
        if(v.equals(btnFive))
            textResult.append("5");
        if(v.equals(btnSix))
            textResult.append("6");
        if(v.equals(btnSeven))
            textResult.append("7");
        if(v.equals(btnEight))
            textResult.append("8");
        if(v.equals(btnNine))
            textResult.append("9");
        if(v.equals(btnZero))
            textResult.append("0");
        if(v.equals(btnDot))
            textResult.append(".");
        if(v.equals(btnAdd))
            textResult.append("+");
        if(v.equals(btnMinus))
            textResult.append("-");
        if(v.equals(btnMul))
            textResult.append("*");
        if(v.equals(btnDiv))
            textResult.append("/");
        if(v.equals(btnClear))
            textResult.setText("");
        if(v.equals(btnEqual))
            try {
                String data = textResult.getText().toString();
                if(data.contains("/"))
                    divide(data);
                else if (data.contains("*"))
                    multiply(data);
                else if(data.contains("+"))
                    add(data);
                else if (data.contains("-"))
                    sub(data);
            } catch (Exception e) {
                displayInvalidMessage();
            }
    }

    private void divide(String data) {
        String[] operands = data.split("/");
        if(operands.length==2) {
            Double operand1 = Double.valueOf(operands[0]);
            Double operand2 = Double.valueOf(operands[1]);
            double result= operand1 / operand2;
            textResult.setText(String.valueOf(result));
        } else {
            displayInvalidMessage();
        }
    }

    private void multiply(String data) {
        String[] operands = data.split(Pattern.quote("*"));
        if(operands.length==2) {
            Double operand1 = Double.valueOf(operands[0]);
            Double operand2 = Double.valueOf(operands[1]);
            double result= operand1 * operand2;
            textResult.setText(String.valueOf(result));
        } else {
            displayInvalidMessage();
        }
    }

    private void add(String data) {
        String[] operands = data.split(Pattern.quote("+"));
        if(operands.length==2) {
            Double operand1 = Double.valueOf(operands[0]);
            Double operand2 = Double.valueOf(operands[1]);
            double result= operand1 + operand2;
            textResult.setText(String.valueOf(result));
        } else {
            displayInvalidMessage();
        }
    }

    private void sub(String data) {
        String[] operands = data.split("-");
        if(operands.length==2) {
            Double operand1 = Double.valueOf(operands[0]);
            Double operand2 = Double.valueOf(operands[1]);
            double result= operand1 - operand2;
            textResult.setText(String.valueOf(result));
        } else {
            displayInvalidMessage();
        }
    }

    private void displayInvalidMessage() {
        Toast.makeText(getBaseContext(), "Invalid Input",Toast.LENGTH_LONG).show();
    }
}